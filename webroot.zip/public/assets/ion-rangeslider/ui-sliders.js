/**
* Theme: Montran Admin Template
* Author: Coderthemes
* Component: Ion Slider
* 
*/
$(document).ready(function () {
    $(".range").ionRangeSlider({
        min: 0,
        max: 100
    });
});