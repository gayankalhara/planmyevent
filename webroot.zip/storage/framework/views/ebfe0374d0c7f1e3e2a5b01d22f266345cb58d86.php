<html>
<body>
<?php echo $key; ?>
</body>
</html>