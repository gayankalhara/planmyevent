Mail::raw('Laravel with Mailgun is easy!', function($message)
{
$message->to('gayan.csnc@gmail.com');
});