{{-- Home Page --}}

@extends('master')

@section('content')

@endsection