## Plan My Event

## Official Website

Thge website can be found here. [PlanMyEvent website](http://www.planmyevent.me).

## Contributing

- Gayan Kalhara
- Udesh Hewagama
- Hasitha Jayasinghe
- Lasanthi Kalpani

### License

PlanMyEvent is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
