<?php
/**
 * Created by PhpStorm.
 * User: Hasitha
 * Date: 3/7/2016
 * Time: 1:08 AM
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event_Services extends Model
{
    protected $table = 'event_services';

    public $incrementing = false;

    public $timestamps = false;
}