<?php

namespace App;
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Task_Templates extends Model
{
    protected $table = 'task_templates';

    public $timestamps = false;
}
