<?php

namespace App;
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class service_providers extends Model
{
    protected $table = 'service_providers';

    public $timestamps = false;
}
