<?php

namespace App;
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class services extends Model
{
    protected $table = 'services';

    public $timestamps = false;
}
